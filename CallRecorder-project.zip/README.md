# Запись звонков (Android)

Автозапись звонков через микрофон + автоматическая громкая связь.
Сборка: GitHub → Actions → Build APK → Artifacts → ZapisZvonkov-apk.
Локально: `gradle assembleDebug` (JDK 17, Android SDK 34), APK в app/build/outputs/apk/debug/.
