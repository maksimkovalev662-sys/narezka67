package com.foptop.callrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    private static final String CH = "rec";
    private static final String TAG = "CallRecorder";

    private MediaRecorder rec;
    private File file;
    private AudioManager am;
    private boolean started, speakerForced, wasSpeaker, usedComm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable speakerTask = this::enableSpeaker;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (!goForeground()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        started = true;

        String number = i != null ? i.getStringExtra("number") : null;
        if (Prefs.mode(this) == 1 && Util.isKnown(this, number)) {
            stopSelf(); // режим «только неизвестные» — этот контакт в книге, не пишем
            return START_NOT_STICKY;
        }

        Util.cleanOld(this);

        if (Prefs.speaker(this)) {
            enableSpeaker();
            h.postDelayed(speakerTask, 2000);
            h.postDelayed(speakerTask, 6000);
        }

        if (!startRecording(number)) {
            fail();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private boolean goForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(
                    new NotificationChannel(CH, "Запись звонков", NotificationManager.IMPORTANCE_LOW));
            PendingIntent pi = PendingIntent.getActivity(
                    this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("Идёт запись звонка")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(1, n);
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "startForeground не удался", e);
            return false;
        }
    }

    private void fail() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("Не удалось записать звонок")
                    .setContentText("Проверь разрешения или выбери другой источник звука в приложении")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setAutoCancel(true)
                    .build();
            nm.notify(2, n);
        } catch (Exception ignored) {
        }
    }

    private int[] sources() {
        switch (Prefs.source(this)) {
            case 1:
                return new int[]{MediaRecorder.AudioSource.MIC};
            case 2:
                return new int[]{MediaRecorder.AudioSource.VOICE_RECOGNITION};
            case 3:
                return new int[]{MediaRecorder.AudioSource.VOICE_COMMUNICATION};
            default:
                return new int[]{
                        MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        MediaRecorder.AudioSource.MIC,
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION};
        }
    }

    private boolean startRecording(String number) {
        String ts = new SimpleDateFormat(Util.DATE_FMT, Locale.US).format(new Date());
        String num = number == null ? "" : number.replaceAll("[^0-9+]", "");
        file = new File(Util.dir(this), ts + "_" + (num.isEmpty() ? "unknown" : num) + ".m4a");

        for (int src : sources()) {
            if (tryStart(src)) return true;
        }
        return false;
    }

    @SuppressWarnings("deprecation")
    private boolean tryStart(int src) {
        MediaRecorder r = null;
        try {
            r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            r.setAudioSource(src);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioChannels(1);
            r.setAudioSamplingRate(44100);
            r.setAudioEncodingBitRate(96000);
            r.setOutputFile(file.getAbsolutePath());
            r.prepare();
            r.start();
            rec = r;
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Источник " + src + " не сработал", e);
            if (r != null) {
                try { r.release(); } catch (Exception ignored) { }
            }
            if (file != null) file.delete();
            return false;
        }
    }

    private void stopRecording() {
        if (rec != null) {
            try {
                rec.stop();
            } catch (Exception e) {
                if (file != null) file.delete();
            }
            try { rec.release(); } catch (Exception ignored) { }
            rec = null;
        }
        if (file != null && file.exists() && file.length() < 2048) file.delete();
    }

    @SuppressWarnings("deprecation")
    private void enableSpeaker() {
        try {
            if (am == null) am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (!speakerForced) wasSpeaker = am.isSpeakerphoneOn();
            if (Build.VERSION.SDK_INT >= 31) {
                for (AudioDeviceInfo d : am.getAvailableCommunicationDevices()) {
                    if (d.getType() == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) {
                        am.setCommunicationDevice(d);
                        usedComm = true;
                        break;
                    }
                }
            }
            am.setSpeakerphoneOn(true);
            speakerForced = true;
        } catch (Exception e) {
            Log.e(TAG, "Громкая связь не включилась", e);
        }
    }

    @SuppressWarnings("deprecation")
    private void restoreSpeaker() {
        if (!speakerForced || am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 31 && usedComm) am.clearCommunicationDevice();
            if (!wasSpeaker) am.setSpeakerphoneOn(false);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(speakerTask);
        stopRecording();
        restoreSpeaker();
        super.onDestroy();
    }
}
