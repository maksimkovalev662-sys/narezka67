package com.foptop.callrecorder;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private Prefs() {}

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("p", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return sp(c).getBoolean("enabled", true); }
    static boolean speaker(Context c) { return sp(c).getBoolean("speaker", true); }
    /** 0 = все звонки, 1 = только неизвестные номера */
    static int mode(Context c) { return sp(c).getInt("mode", 0); }
    /** 0 = не удалять, иначе количество дней */
    static int keepDays(Context c) { return sp(c).getInt("keep", 0); }
    /** 0 = авто, 1 = MIC, 2 = VOICE_RECOGNITION, 3 = VOICE_COMMUNICATION */
    static int source(Context c) { return sp(c).getInt("source", 0); }

    static void setNumber(Context c, String n) {
        if (n == null || n.isEmpty()) return;
        sp(c).edit().putString("num", n).putLong("num_t", System.currentTimeMillis()).apply();
    }

    static String number(Context c) {
        long t = sp(c).getLong("num_t", 0);
        if (System.currentTimeMillis() - t > 5 * 60 * 1000L) return null;
        return sp(c).getString("num", null);
    }

    static void clearNumber(Context c) {
        sp(c).edit().remove("num").remove("num_t").apply();
    }
}
