package com.foptop.callrecorder;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

final class Util {
    private Util() {}

    static final String DATE_FMT = "yyyy-MM-dd_HH-mm-ss";

    static File dir(Context c) {
        File d = c.getExternalFilesDir("records");
        if (d == null) d = new File(c.getFilesDir(), "records");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static List<File> list(Context c) {
        File[] a = dir(c).listFiles((d, n) -> n.endsWith(".m4a"));
        List<File> l = new ArrayList<>();
        if (a != null) {
            Arrays.sort(a, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
            l.addAll(Arrays.asList(a));
        }
        return l;
    }

    static void cleanOld(Context c) {
        int days = Prefs.keepDays(c);
        if (days <= 0) return;
        long limit = System.currentTimeMillis() - days * 86400000L;
        for (File f : list(c)) {
            if (f.lastModified() < limit) f.delete();
        }
    }

    static String contactName(Context c, String number) {
        if (number == null || number.isEmpty()) return null;
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        Uri u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
        try (Cursor cur = c.getContentResolver().query(
                u, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Exception ignored) {
        }
        return null;
    }

    static boolean isKnown(Context c, String number) {
        return contactName(c, number) != null;
    }

    static String sizeStr(long b) {
        if (b >= 1024 * 1024) return String.format(Locale.US, "%.1f МБ", b / 1048576.0);
        return (b / 1024) + " КБ";
    }

    /** Возвращает {заголовок, подпись} для строки списка. */
    static String[] describe(Context c, File f) {
        String n = f.getName();
        n = n.substring(0, n.length() - 4);
        String num = n.length() > 20 ? n.substring(20) : "";
        if (num.equals("unknown")) num = "";

        Date d = null;
        try {
            d = new SimpleDateFormat(DATE_FMT, Locale.US).parse(n.substring(0, Math.min(19, n.length())));
        } catch (Exception ignored) {
        }
        if (d == null) d = new Date(f.lastModified());
        String when = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(d);

        String name = contactName(c, num);
        String title = name != null ? name : (num.isEmpty() ? "Номер не определён" : num);
        String sub = when + " • " + (name != null ? num + " • " : "") + sizeStr(f.length());
        return new String[]{title, sub};
    }
}
