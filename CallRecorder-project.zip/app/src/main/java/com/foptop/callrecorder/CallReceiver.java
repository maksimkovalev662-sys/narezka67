package com.foptop.callrecorder;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.util.Log;

public class CallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (a == null) return;

        if (Intent.ACTION_NEW_OUTGOING_CALL.equals(a)) {
            Prefs.setNumber(c, i.getStringExtra(Intent.EXTRA_PHONE_NUMBER));
            return;
        }
        if (!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(a)) return;

        String state = i.getStringExtra(TelephonyManager.EXTRA_STATE);
        Prefs.setNumber(c, i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER));

        if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
            if (!Prefs.enabled(c)) return;
            if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) return;
            Intent s = new Intent(c, RecorderService.class);
            s.putExtra("number", Prefs.number(c));
            try {
                c.startForegroundService(s);
            } catch (Exception e) {
                Log.e("CallRecorder", "Не удалось запустить службу записи", e);
            }
        } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state)) {
            c.stopService(new Intent(c, RecorderService.class));
            Prefs.clearNumber(c);
        }
    }
}
