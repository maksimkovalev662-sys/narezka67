package com.foptop.callrecorder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    private static final int[] KEEP_DAYS = {0, 7, 30, 90};

    private LinearLayout root, listBox;
    private TextView status;
    private MediaPlayer player;
    private File playing;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(28), dp(16), dp(24));
        sv.addView(root);
        setContentView(sv);
        build();
    }

    private void build() {
        root.addView(text("Запись звонков", 26, true));
        root.addView(text("Приложение пишет звук через микрофон, поэтому собеседника слышно "
                + "только на громкой связи (её приложение включает само). "
                + "Записывай разговоры в рамках закона: в ряде стран нужно предупреждать собеседника.", 13, false));

        status = text("", 14, false);
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status);

        root.addView(button("1. Выдать разрешения", v -> requestPermissions(perms(), 1)));
        root.addView(button("2. Показ поверх других окон", v -> openOverlay()));
        root.addView(button("3. Не ограничивать батарею", v -> openBattery()));
        root.addView(button("Настройки приложения", v -> openAppSettings()));

        root.addView(switchRow("Записывать звонки", Prefs.enabled(this),
                (cb, on) -> Prefs.sp(this).edit().putBoolean("enabled", on).apply()));
        root.addView(switchRow("Включать громкую связь", Prefs.speaker(this),
                (cb, on) -> Prefs.sp(this).edit().putBoolean("speaker", on).apply()));

        root.addView(spinnerRow("Что записывать",
                new String[]{"Все звонки", "Только неизвестные номера"},
                Prefs.mode(this),
                p -> Prefs.sp(this).edit().putInt("mode", p).apply()));

        int keepIdx = 0;
        for (int k = 0; k < KEEP_DAYS.length; k++) if (KEEP_DAYS[k] == Prefs.keepDays(this)) keepIdx = k;
        root.addView(spinnerRow("Автоудаление записей",
                new String[]{"Не удалять", "Через 7 дней", "Через 30 дней", "Через 90 дней"},
                keepIdx,
                p -> Prefs.sp(this).edit().putInt("keep", KEEP_DAYS[p]).apply()));

        root.addView(spinnerRow("Источник звука (если записывается тишина — смени)",
                new String[]{"Авто", "Микрофон", "Распознавание речи", "Связь (VoIP)"},
                Prefs.source(this),
                p -> Prefs.sp(this).edit().putInt("source", p).apply()));

        TextView h = text("Записи", 20, true);
        h.setPadding(0, dp(24), 0, dp(4));
        root.addView(h);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshList();
    }

    @Override
    protected void onDestroy() {
        stopPlayer();
        super.onDestroy();
    }

    // ---------- разрешения ----------

    private String[] perms() {
        List<String> l = new ArrayList<>(Arrays.asList(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.PROCESS_OUTGOING_CALLS));
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS);
        return l.toArray(new String[0]);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        refreshStatus();
        refreshList();
    }

    private boolean has(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private String mark(boolean ok) {
        return ok ? "✅" : "❌";
    }

    private void refreshStatus() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        boolean batt = pm.isIgnoringBatteryOptimizations(getPackageName());
        String s = mark(has(Manifest.permission.RECORD_AUDIO)) + " Микрофон\n"
                + mark(has(Manifest.permission.READ_PHONE_STATE)) + " Состояние телефона (начало и конец звонка)\n"
                + mark(has(Manifest.permission.READ_CALL_LOG)) + " Журнал звонков (номер собеседника)\n"
                + mark(has(Manifest.permission.READ_CONTACTS)) + " Контакты (имена и фильтр «неизвестные»)\n"
                + mark(Settings.canDrawOverlays(this)) + " Показ поверх других окон (чтобы запись стартовала в фоне)\n"
                + mark(batt) + " Без ограничений батареи";
        status.setText(s);
    }

    private void openOverlay() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            openAppSettings();
        }
    }

    private void openBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e2) {
                openAppSettings();
            }
        }
    }

    private void openAppSettings() {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    // ---------- список записей ----------

    private void refreshList() {
        Util.cleanOld(this);
        listBox.removeAllViews();
        List<File> files = Util.list(this);
        if (files.isEmpty()) {
            listBox.addView(text("Пока нет записей. Позвони кому-нибудь — запись появится здесь.", 14, false));
            return;
        }
        for (File f : files) listBox.addView(row(f));
    }

    private View row(final File f) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(12), 0, dp(8));

        String[] info = Util.describe(this, f);
        r.addView(text(info[0], 17, true));
        r.addView(text(info[1], 13, false));

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.addView(smallButton(f.equals(playing) ? "■ Стоп" : "▶ Слушать", v -> togglePlay(f)));
        btns.addView(smallButton("Поделиться", v -> share(f)));
        btns.addView(smallButton("Удалить", v -> confirmDelete(f)));
        r.addView(btns);

        View d = new View(this);
        d.setBackgroundColor(0x33FFFFFF);
        r.addView(d, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));
        return r;
    }

    private void togglePlay(File f) {
        boolean same = f.equals(playing);
        stopPlayer();
        if (!same) {
            try {
                player = new MediaPlayer();
                player.setDataSource(f.getAbsolutePath());
                player.setOnCompletionListener(mp -> {
                    stopPlayer();
                    refreshList();
                });
                player.prepare();
                player.start();
                playing = f;
            } catch (Exception e) {
                stopPlayer();
                Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
            }
        }
        refreshList();
    }

    private void stopPlayer() {
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        playing = null;
    }

    private void share(File f) {
        try {
            Uri u = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("audio/mp4");
            s.putExtra(Intent.EXTRA_STREAM, u);
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(s, "Поделиться записью"));
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось поделиться", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmDelete(final File f) {
        new AlertDialog.Builder(this)
                .setMessage("Удалить эту запись?")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Удалить", (d, w) -> {
                    if (f.equals(playing)) stopPlayer();
                    f.delete();
                    refreshList();
                })
                .show();
    }

    // ---------- элементы интерфейса ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private Button button(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private Button smallButton(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    private Switch switchRow(String label, boolean value, CompoundButton.OnCheckedChangeListener l) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setChecked(value);
        sw.setOnCheckedChangeListener(l);
        sw.setPadding(0, dp(12), 0, dp(12));
        return sw;
    }

    private View spinnerRow(String label, String[] items, int sel, final IntConsumer onSelect) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(0, dp(8), 0, 0);
        l.addView(text(label, 14, false));
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setSelection(sel);
        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                onSelect.accept(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        l.addView(s);
        return l;
    }
}
